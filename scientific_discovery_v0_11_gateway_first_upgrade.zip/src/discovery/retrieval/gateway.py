from __future__ import annotations

from collections.abc import Mapping
from typing import Any

import httpx
from pydantic import HttpUrl

from discovery.core.ids import stable_id
from discovery.core.provenance import ProvenanceRecord, RightsStatement
from discovery.corpus.schema import Asset, IdentifierScheme, Work, WorkIdentifier, WorkVersion
from discovery.retrieval.feed402 import (
    Feed402Asset,
    Feed402Citation,
    Feed402Envelope,
    Feed402ProtocolError,
    RecordedFeed402Envelope,
    parse_optional_feed402_envelope,
)
from discovery.retrieval.gateway_models import (
    GatewayCoverageReport,
    GatewayHarvestPage,
    GatewaySyncProvider,
    GatewaySyncReport,
    IdentityAssertion,
    IdentityResolution,
    IntegrityAssertion,
    IntegrityReport,
)
from discovery.retrieval.http import RequestObserver, ResilientHttpClient, RetryPolicy
from discovery.retrieval.manifest import GatewayManifest, GatewayOperation, parse_gateway_manifest
from discovery.retrieval.models import (
    AssetResponse,
    CitationEdge,
    CitationResponse,
    FetchResponse,
    ProviderReport,
    RetrievalHit,
    SearchQuery,
    SearchResponse,
)
from discovery.retrieval.provider import CapabilityUnavailable


class GatewayProtocolError(RuntimeError):
    pass


def _as_mapping(value: object) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _first_string(record: Mapping[str, Any], names: tuple[str, ...]) -> str | None:
    for name in names:
        value = record.get(name)
        if isinstance(value, str) and value.strip():
            return value
    return None


def _normalize_identifier(record: Mapping[str, Any], provider: str) -> WorkIdentifier | None:
    candidates: tuple[tuple[str, IdentifierScheme], ...] = (
        ("doi", IdentifierScheme.DOI),
        ("pmid", IdentifierScheme.PMID),
        ("pmcid", IdentifierScheme.PMCID),
        ("arxiv_id", IdentifierScheme.ARXIV),
        ("openalex_id", IdentifierScheme.OPENALEX),
        ("id", IdentifierScheme.OTHER),
    )
    for key, scheme in candidates:
        value = record.get(key)
        if isinstance(value, str) and value.strip():
            return WorkIdentifier(scheme=scheme, value=value, provider=provider, raw_value=value)
    return None


def _work_from_record(record: Mapping[str, Any], provider: str) -> Work | None:
    title = _first_string(record, ("title", "display_name", "name"))
    if title is None:
        return None
    identifier = _normalize_identifier(record, provider)
    raw_id = identifier.value if identifier else title
    year_value = record.get("publication_year", record.get("year"))
    year = year_value if isinstance(year_value, int) else None
    abstract = _first_string(record, ("abstract", "abstract_text", "summary"))
    return Work(
        id=stable_id("gateway-work", f"{provider}:{raw_id}"),
        title=title,
        abstract=abstract,
        publication_year=year,
        identifiers=[identifier] if identifier else [],
        version=WorkVersion(provider=provider, raw_record=dict(record)),
        metadata={"gateway_provider": provider},
    )


def _provenance_from_citation(value: object) -> ProvenanceRecord | None:
    citation = _as_mapping(value)
    if not citation:
        return None
    try:
        return Feed402Citation.model_validate(citation).provenance()
    except Exception:
        provider = _first_string(citation, ("provider", "source_id")) or "unknown"
        return ProvenanceRecord(
            provider=provider,
            source_identifier=_first_string(citation, ("source_id",)),
        )


def _asset_from_mapping(value: Mapping[str, Any], work_id: str, provider: str) -> Asset:
    try:
        feed_asset = Feed402Asset.model_validate(value)
        return feed_asset.to_asset(work_id=work_id, provider=provider)
    except Exception:
        rights = _as_mapping(value.get("rights"))
        metadata_rights = _as_mapping(rights.get("metadata"))
        content_rights = _as_mapping(rights.get("content"))
        statement = RightsStatement(
            metadata_license=_first_string(metadata_rights, ("license",)),
            content_license=_first_string(content_rights, ("license",)),
            redistribution=_first_string(rights, ("redistribution",)) or "unknown",
            tdm=_first_string(rights, ("tdm",)) or "unknown",
            model_training=_first_string(rights, ("model_training",)) or "unknown",
            retention=_first_string(rights, ("retention",)) or "unknown",
            terms_url=_first_string(rights, ("terms_url",)),
        )
        asset_id = _first_string(value, ("asset_id", "id")) or stable_id(
            "asset",
            f"{work_id}:{provider}:{value.get('canonical_url')}:{value.get('representation')}",
        )
        raw_url = _first_string(value, ("canonical_url", "provider_url", "url"))
        return Asset(
            id=asset_id,
            provider=provider,
            representation=_first_string(value, ("representation", "content_type")) or "unknown",
            url=HttpUrl(raw_url) if raw_url is not None else None,
            mime_type=_first_string(value, ("mime_type", "content_type")),
            availability=_first_string(value, ("availability",)) or "unknown",
            rights=statement,
            checksum=_first_string(value, ("checksum",)),
        )


class GatewayProvider:
    """Canonical external-research boundary for scientific-discovery.

    Every paid scientific response is required to arrive as a feed402 envelope.
    Provider-specific acquisition logic belongs behind x402-research-gateway.
    """

    name = "x402-research-gateway"
    boundary_kind = "gateway"

    def __init__(
        self,
        base_url: str,
        *,
        timeout_seconds: float = 30.0,
        client: httpx.Client | None = None,
        retry_policy: RetryPolicy | None = None,
        observer: RequestObserver | None = None,
        headers: Mapping[str, str] | None = None,
        strict_feed402: bool = True,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.client = client or httpx.Client(
            base_url=self.base_url,
            timeout=timeout_seconds,
            follow_redirects=True,
            headers=dict(headers or {}),
        )
        self._owns_client = client is None
        self.http = ResilientHttpClient(
            self.client, retry_policy=retry_policy, observer=observer
        )
        self._manifest: GatewayManifest | None = None
        self.strict_feed402 = strict_feed402
        self._recorded_envelopes: list[RecordedFeed402Envelope] = []

    def close(self) -> None:
        if self._owns_client:
            self.client.close()

    def _decode_feed402(
        self,
        operation: str,
        payload: Mapping[str, Any],
        *,
        require_citations: bool = True,
    ) -> Feed402Envelope:
        try:
            envelope = Feed402Envelope.from_mapping(
                payload,
                require_citations=require_citations and self.strict_feed402,
                require_receipt=self.strict_feed402,
            )
        except Feed402ProtocolError as exc:
            raise GatewayProtocolError(
                f"{operation} returned a non-feed402 response: {exc}"
            ) from exc
        self._recorded_envelopes.append(
            RecordedFeed402Envelope(operation=operation, envelope=envelope)
        )
        return envelope

    def drain_feed402_envelopes(self) -> list[RecordedFeed402Envelope]:
        recorded = list(self._recorded_envelopes)
        self._recorded_envelopes.clear()
        return recorded

    def manifest(self, *, refresh: bool = False) -> GatewayManifest:
        if self._manifest is not None and not refresh:
            return self._manifest
        errors: list[str] = []
        for path in ("/.well-known/feed402.json", "/feed402.json"):
            response = self.http.request(
                "GET", path, provider=self.name, operation="manifest"
            )
            if response.status_code == 404:
                errors.append(f"{path}:404")
                continue
            response.raise_for_status()
            payload = response.json()
            if not isinstance(payload, dict):
                raise GatewayProtocolError("gateway manifest is not an object")
            self._manifest = parse_gateway_manifest(payload)
            if self.strict_feed402 and not (
                self._manifest.spec is not None
                and self._manifest.spec.startswith("feed402/")
            ):
                raise GatewayProtocolError(
                    "gateway manifest does not advertise a feed402 protocol version"
                )
            return self._manifest
        raise GatewayProtocolError("gateway manifest unavailable: " + ", ".join(errors))

    def operation(self, operation_id: str) -> GatewayOperation:
        for item in self.manifest().operations:
            if item.operation_id == operation_id:
                return item
        raise CapabilityUnavailable(f"gateway operation not advertised: {operation_id}")

    def invoke(self, operation_id: str, payload: dict[str, object]) -> dict[str, object]:
        operation = self.operation(operation_id)
        if operation.method.upper() == "GET":
            response = self.http.request(
                "GET",
                operation.path,
                provider=self.name,
                operation=operation_id,
                params=payload,
            )
        else:
            response = self.http.request(
                operation.method.upper(),
                operation.path,
                provider=self.name,
                operation=operation_id,
                json_body=payload,
            )
        response.raise_for_status()
        value = response.json()
        if not isinstance(value, dict):
            raise GatewayProtocolError(f"operation {operation_id} returned a non-object")
        self._decode_feed402(operation_id, value)
        return value

    def estimate_search(self, query: SearchQuery) -> dict[str, object]:
        params: dict[str, str] = {"query": query.text, "limit": str(query.limit)}
        if query.max_cost_usd is not None:
            params["max_cost_usd"] = str(query.max_cost_usd)
        response = self.http.request(
            "GET",
            "/research/federated",
            provider=self.name,
            operation="federated-estimate",
            params=params,
        )
        response.raise_for_status()
        payload = response.json()
        if not isinstance(payload, dict):
            raise GatewayProtocolError("gateway estimate returned a non-object")
        return payload

    def resolve(self, identifier: str) -> dict[str, object]:
        response = self.http.request(
            "POST",
            "/research/resolve",
            provider=self.name,
            operation="resolve",
            json_body={"identifier": identifier},
        )
        response.raise_for_status()
        payload = response.json()
        if not isinstance(payload, dict):
            raise GatewayProtocolError("gateway resolve returned a non-object")
        self._decode_feed402("resolve", payload)
        return payload

    def resolve_identity(self, identifier: str) -> IdentityResolution:
        envelope = self.resolve(identifier)
        data = _as_mapping(envelope.get("data"))
        raw_relations = data.get("relations", data.get("edges", data.get("assertions", [])))
        relations = raw_relations if isinstance(raw_relations, list) else []
        assertions: list[IdentityAssertion] = []
        for raw in relations:
            relation = _as_mapping(raw)
            source = relation.get("source", relation.get("subject", identifier))
            target = relation.get("target", relation.get("object"))
            source_map = _as_mapping(source)
            target_map = _as_mapping(target)
            source_id = (
                _first_string(source_map, ("raw_id", "id", "identifier"))
                if source_map
                else source if isinstance(source, str) else None
            )
            target_id = (
                _first_string(target_map, ("raw_id", "id", "identifier"))
                if target_map
                else target if isinstance(target, str) else None
            )
            relation_type = _first_string(
                relation, ("relation", "relation_type", "type")
            )
            provider = _first_string(
                relation, ("provider", "asserting_provider", "source_provider")
            ) or "unknown"
            confidence_value = relation.get("confidence", relation.get("score"))
            confidence = (
                float(confidence_value)
                if isinstance(confidence_value, int | float)
                else None
            )
            if source_id and target_id and relation_type:
                assertions.append(
                    IdentityAssertion(
                        source_identifier=source_id,
                        relation_type=relation_type,
                        target_identifier=target_id,
                        provider=provider,
                        confidence=confidence,
                        payload=dict(relation),
                    )
                )
        reports_obj = data.get("providers", data.get("provider_reports", []))
        reports = (
            [dict(item) for item in reports_obj if isinstance(item, Mapping)]
            if isinstance(reports_obj, list)
            else []
        )
        return IdentityResolution(
            query_identifier=identifier,
            assertions=assertions,
            provider_reports=reports,
            raw_envelope=envelope,
        )

    def integrity(self, identifier: str) -> IntegrityReport:
        response = self.http.request(
            "POST",
            "/research/integrity",
            provider=self.name,
            operation="integrity",
            json_body={"identifier": identifier},
        )
        response.raise_for_status()
        envelope = response.json()
        if not isinstance(envelope, dict):
            raise GatewayProtocolError("gateway integrity returned a non-object")
        self._decode_feed402("integrity", envelope)
        data = _as_mapping(envelope.get("data"))
        raw_assertions = data.get("relations", data.get("notices", data.get("assertions", [])))
        values = raw_assertions if isinstance(raw_assertions, list) else []
        assertions: list[IntegrityAssertion] = []
        for raw in values:
            value = _as_mapping(raw)
            subject = value.get("subject", identifier)
            target = value.get("target", value.get("object"))
            subject_map = _as_mapping(subject)
            target_map = _as_mapping(target)
            subject_id = (
                _first_string(subject_map, ("raw_id", "id", "identifier"))
                if subject_map
                else subject if isinstance(subject, str) else identifier
            )
            target_id = (
                _first_string(target_map, ("raw_id", "id", "identifier"))
                if target_map
                else target if isinstance(target, str) else None
            )
            relation_type = _first_string(value, ("relation", "relation_type", "type", "status"))
            if relation_type is None:
                continue
            assertions.append(
                IntegrityAssertion(
                    subject_identifier=subject_id or identifier,
                    relation_type=relation_type,
                    object_identifier=target_id,
                    provider=_first_string(value, ("provider", "asserting_provider")) or "unknown",
                    status=_first_string(value, ("status",)) or "asserted",
                    payload=dict(value),
                )
            )
        reports_obj = data.get("providers", data.get("provider_reports", []))
        reports = (
            [dict(item) for item in reports_obj if isinstance(item, Mapping)]
            if isinstance(reports_obj, list)
            else []
        )
        return IntegrityReport(
            query_identifier=identifier,
            assertions=assertions,
            provider_reports=reports,
            raw_envelope=envelope,
        )

    def sync_status(self) -> GatewaySyncReport:
        response = self.http.request(
            "GET", "/research/sync", provider=self.name, operation="sync-discovery"
        )
        response.raise_for_status()
        envelope = response.json()
        if not isinstance(envelope, dict):
            raise GatewayProtocolError("gateway sync discovery returned a non-object")
        data = _as_mapping(envelope.get("data")) or envelope
        raw_providers = data.get("providers", [])
        providers: list[GatewaySyncProvider] = []
        if isinstance(raw_providers, list):
            for raw in raw_providers:
                value = _as_mapping(raw)
                provider_name = _first_string(value, ("provider", "id", "name"))
                if provider_name is None:
                    continue
                raw_caps = value.get("capabilities", [])
                caps = [str(item) for item in raw_caps] if isinstance(raw_caps, list) else []
                providers.append(
                    GatewaySyncProvider(
                        provider=provider_name,
                        status=_first_string(value, ("status", "lifecycle")) or "unknown",
                        capabilities=caps,
                        bulk=dict(_as_mapping(value.get("bulk"))),
                        incremental=dict(_as_mapping(value.get("incremental"))),
                        last_verified=_first_string(value, ("last_verified",)),
                        payload=dict(value),
                    )
                )
        return GatewaySyncReport(providers=providers, raw_envelope=envelope)

    def coverage_report(self, **params: object) -> GatewayCoverageReport:
        response = self.http.request(
            "GET",
            "/research/coverage",
            provider=self.name,
            operation="coverage",
            params=params,
        )
        response.raise_for_status()
        envelope = response.json()
        if not isinstance(envelope, dict):
            raise GatewayProtocolError("gateway coverage returned a non-object")
        data = _as_mapping(envelope.get("data")) or envelope
        gaps_obj = data.get("gaps", [])
        gaps = (
            [dict(item) for item in gaps_obj if isinstance(item, Mapping)]
            if isinstance(gaps_obj, list)
            else []
        )
        dimensions = {
            str(key): value
            for key, value in data.items()
            if key not in {"gaps", "providers", "provider_reports"}
        }
        return GatewayCoverageReport(
            dimensions=dimensions, gaps=gaps, raw_envelope=envelope
        )

    def harvest_page(self, payload: dict[str, object]) -> GatewayHarvestPage:
        response = self.http.request(
            "POST",
            "/research/harvest",
            provider=self.name,
            operation="harvest-page",
            json_body=payload,
        )
        response.raise_for_status()
        envelope = response.json()
        if not isinstance(envelope, dict):
            raise GatewayProtocolError("gateway harvest returned a non-object")
        self._decode_feed402("harvest-page", envelope)
        data = _as_mapping(envelope.get("data"))
        raw_records = data.get("records", data.get("rows", data.get("hits", [])))
        records = (
            [dict(item) for item in raw_records if isinstance(item, Mapping)]
            if isinstance(raw_records, list)
            else []
        )
        cursor = _first_string(data, ("next_cursor", "cursor"))
        exhausted_value = data.get("exhausted")
        exhausted = bool(exhausted_value) if isinstance(exhausted_value, bool) else not bool(cursor)
        ephemeral_value = data.get("cursor_ephemeral")
        return GatewayHarvestPage(
            provider=_first_string(data, ("provider",)),
            records=records,
            cursor=cursor,
            exhausted=exhausted,
            cursor_ephemeral=ephemeral_value if isinstance(ephemeral_value, bool) else None,
            raw_envelope=envelope,
        )

    def search(self, query: SearchQuery) -> SearchResponse:
        payload: dict[str, object] = {"query": query.text, "limit": query.limit}
        if query.providers:
            payload["providers"] = query.providers
        if query.filters:
            payload["filters"] = query.filters
        if query.max_cost_usd is not None:
            payload["max_cost_usd"] = query.max_cost_usd

        response = self.http.request(
            "POST",
            "/research/federated",
            provider=self.name,
            operation="federated-search",
            json_body=payload,
        )
        response.raise_for_status()
        envelope = response.json()
        if not isinstance(envelope, dict):
            raise GatewayProtocolError("gateway returned a non-object envelope")
        self._decode_feed402("federated-search", envelope)
        return self.parse_search_response(query, envelope)

    @staticmethod
    def parse_search_response(query: SearchQuery, envelope: Mapping[str, Any]) -> SearchResponse:
        data = _as_mapping(envelope.get("data"))
        results_obj = data.get("results", data.get("rows", data.get("hits", [])))
        results = results_obj if isinstance(results_obj, list) else []
        typed_envelope = parse_optional_feed402_envelope(envelope)

        hits: list[RetrievalHit] = []
        for index, raw in enumerate(results, start=1):
            record = _as_mapping(raw)
            citation = (
                typed_envelope.citation_for_result(index - 1)
                if typed_envelope is not None
                else None
            )
            provider = (
                _first_string(record, ("provider", "source", "source_id"))
                or (citation.provider if citation is not None else None)
                or "unknown"
            )
            raw_record = _as_mapping(record.get("raw_record", record.get("record", record)))
            rank_value = record.get("provider_rank", record.get("rank", index))
            rank = rank_value if isinstance(rank_value, int) and rank_value > 0 else index
            fused_value = record.get("fused_rank")
            fused_rank = fused_value if isinstance(fused_value, int) and fused_value > 0 else None
            score_value = record.get("provider_score", record.get("score"))
            score = float(score_value) if isinstance(score_value, int | float) else None
            work = _work_from_record(raw_record, provider)
            hits.append(
                RetrievalHit(
                    provider=provider,
                    provider_rank=rank,
                    provider_score=score,
                    fused_rank=fused_rank,
                    work=work,
                    raw_record=dict(raw_record),
                    provenance=citation.provenance() if citation is not None else None,
                )
            )

        reports: list[ProviderReport] = []
        providers_obj = data.get("providers", data.get("provider_reports", []))
        if isinstance(providers_obj, list):
            for item in providers_obj:
                report = _as_mapping(item)
                provider = _first_string(report, ("provider", "name", "id")) or "unknown"
                status = _first_string(report, ("status", "outcome")) or "unknown"
                count = report.get("result_count")
                reports.append(
                    ProviderReport(
                        provider=provider,
                        status=status,
                        result_count=count if isinstance(count, int) else None,
                        reason=_first_string(report, ("reason", "message")),
                    )
                )
        return SearchResponse(
            query=query,
            hits=hits,
            provider_reports=reports,
            raw_envelope=dict(envelope),
        )

    def fetch(self, identifier: str) -> FetchResponse:
        fetch_ops = self.manifest().operations_for("fetch")
        if len(fetch_ops) != 1:
            raise CapabilityUnavailable(
                "generic fetch is ambiguous; call fetch_with_operation with an advertised operation"
            )
        return self.fetch_with_operation(fetch_ops[0].operation_id, identifier)

    def fetch_with_operation(
        self,
        operation_id: str,
        identifier: str,
        *,
        identifier_field: str = "id",
    ) -> FetchResponse:
        envelope = self.invoke(operation_id, {identifier_field: identifier})
        data = _as_mapping(envelope.get("data"))
        record = _as_mapping(data.get("record", data.get("work", data)))
        self.operation(operation_id)
        provider = operation_id.split("-", 1)[0]
        work = _work_from_record(record, provider) if record else None
        citation_obj = envelope.get("citation")
        citation = citation_obj[0] if isinstance(citation_obj, list) and citation_obj else None
        return FetchResponse(
            provider=provider,
            work=work,
            provenance=_provenance_from_citation(citation),
            raw_envelope=envelope,
        )

    def references(self, identifier: str) -> CitationResponse:
        return self._citations(identifier, "references")

    def cited_by(self, identifier: str) -> CitationResponse:
        return self._citations(identifier, "cited_by")

    def _citations(self, identifier: str, direction: str) -> CitationResponse:
        response = self.http.request(
            "POST",
            "/research/citations",
            provider=self.name,
            operation="citations",
            json_body={"identifier": identifier, "direction": direction},
        )
        response.raise_for_status()
        envelope = response.json()
        if not isinstance(envelope, dict):
            raise GatewayProtocolError("gateway returned a non-object citation envelope")
        self._decode_feed402(f"citations:{direction}", envelope)
        data = _as_mapping(envelope.get("data"))
        edge_objects = data.get("edges", [])
        edges: list[CitationEdge] = []
        if isinstance(edge_objects, list):
            for raw_edge in edge_objects:
                edge = _as_mapping(raw_edge)
                source = _as_mapping(edge.get("source"))
                target = _as_mapping(edge.get("target"))
                source_id = _first_string(source, ("raw_id", "id")) or "unknown"
                target_id = _first_string(target, ("raw_id", "id")) or "unknown"
                provider = _first_string(edge, ("provider", "asserting_provider")) or "unknown"
                edges.append(
                    CitationEdge(
                        source_id=source_id,
                        target_id=target_id,
                        provider=provider,
                        provider_edge_id=_first_string(edge, ("edge_id", "id")),
                        metadata=dict(edge),
                    )
                )
        reports: list[ProviderReport] = []
        provider_objects = data.get("providers", data.get("provider_reports", []))
        if isinstance(provider_objects, list):
            for raw in provider_objects:
                value = _as_mapping(raw)
                reports.append(
                    ProviderReport(
                        provider=_first_string(value, ("provider", "name")) or "unknown",
                        status=_first_string(value, ("status", "outcome")) or "unknown",
                        result_count=value.get("edge_count")
                        if isinstance(value.get("edge_count"), int)
                        else None,
                        reason=_first_string(value, ("reason",)),
                    )
                )
        return CitationResponse(
            identifier=identifier,
            direction=direction,
            edges=edges,
            provider_reports=reports,
        )

    def assets(self, identifier: str) -> AssetResponse:
        asset_ops = self.manifest().operations_for("assets")
        if len(asset_ops) != 1:
            raise CapabilityUnavailable(
                "generic asset discovery is ambiguous; call assets_with_operation"
            )
        return self.assets_with_operation(asset_ops[0].operation_id, identifier)

    def assets_with_operation(
        self,
        operation_id: str,
        identifier: str,
        *,
        identifier_field: str = "id",
    ) -> AssetResponse:
        envelope = self.invoke(operation_id, {identifier_field: identifier})
        data = _as_mapping(envelope.get("data"))
        raw_assets = data.get("assets", [])
        typed_envelope = Feed402Envelope.from_mapping(envelope)
        source_citation = (
            typed_envelope.source_citations[0]
            if typed_envelope.source_citations
            else None
        )
        provider = (
            source_citation.provider
            if source_citation is not None and source_citation.provider is not None
            else operation_id.split("-", 1)[0]
        )
        work_id = stable_id("external-work", identifier)
        assets: list[Asset] = []
        if isinstance(raw_assets, list) and raw_assets:
            for item in raw_assets:
                if not isinstance(item, Mapping):
                    continue
                try:
                    feed_asset = Feed402Asset.model_validate(item)
                    assets.append(
                        feed_asset.to_asset(
                            work_id=work_id,
                            provider=provider,
                            inherited_rights=(
                                source_citation.rights
                                if source_citation is not None
                                else None
                            ),
                        )
                    )
                except Exception:
                    assets.append(_asset_from_mapping(item, work_id, provider))
        elif source_citation is not None:
            assets = [
                item.to_asset(
                    work_id=work_id,
                    provider=provider,
                    inherited_rights=source_citation.rights,
                )
                for item in source_citation.assets
            ]
        return AssetResponse(identifier=identifier, assets=assets)
