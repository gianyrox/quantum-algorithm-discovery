"""Scientific Discovery research engine."""

__version__ = "0.10.0"
